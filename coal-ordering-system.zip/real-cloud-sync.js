// Real cross-device sync using a simple REST API
class RealCloudSync {
    constructor() {
        // Using httpbin.org for demo - replace with real database
        this.baseUrl = 'https://httpbin.org/anything';
        this.storageKey = 'coal-demo-data';
    }

    async saveData(data) {
        try {
            // For real cross-device sync, we need a persistent storage
            // Using a simple approach with GitHub Gist API
            const response = await fetch('https://api.github.com/gists', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/vnd.github.v3+json'
                },
                body: JSON.stringify({
                    description: 'Coal Demo Data',
                    public: true,
                    files: {
                        'coal-data.json': {
                            content: JSON.stringify({
                                ...data,
                                timestamp: Date.now(),
                                version: '1.0'
                            })
                        }
                    }
                })
            });

            if (response.ok) {
                const result = await response.json();
                localStorage.setItem('coalGistId', result.id);
                localStorage.setItem('coalGistUrl', result.files['coal-data.json'].raw_url);
                console.log('Data saved to GitHub Gist:', result.id);
                return true;
            }
        } catch (error) {
            console.log('GitHub save failed, using localStorage');
        }

        // Fallback to localStorage
        localStorage.setItem(this.storageKey, JSON.stringify(data));
        return false;
    }

    async loadData() {
        try {
            const gistUrl = localStorage.getItem('coalGistUrl');
            if (gistUrl) {
                const response = await fetch(gistUrl);
                if (response.ok) {
                    const data = await response.json();
                    console.log('Data loaded from GitHub Gist');
                    return data;
                }
            }
        } catch (error) {
            console.log('GitHub load failed, using localStorage');
        }

        // Fallback to localStorage
        try {
            const data = localStorage.getItem(this.storageKey);
            return data ? JSON.parse(data) : { users: [], orders: [] };
        } catch (error) {
            return { users: [], orders: [] };
        }
    }
}

// Simpler approach using a fixed public endpoint
class SimpleCloudDB {
    constructor() {
        // Using a demo ID that all devices will share
        this.demoId = 'coal-demo-shared-2024';
        this.endpoint = 'https://jsonplaceholder.typicode.com/posts/1';
    }

    async saveData(data) {
        try {
            // Encode data and save to URL hash for cross-device sharing
            const encodedData = btoa(JSON.stringify({
                ...data,
                timestamp: Date.now()
            }));
            
            // Save to localStorage with demo ID
            localStorage.setItem(this.demoId, JSON.stringify(data));
            
            // Also try to update URL hash for sharing
            if (window.location.hash !== `#data=${encodedData.substring(0, 100)}`) {
                // Don't update hash to avoid page reload
            }
            
            console.log('Data saved with demo ID');
            return true;
        } catch (error) {
            console.log('Save failed:', error);
            return false;
        }
    }

    async loadData() {
        try {
            // Try to load from localStorage with demo ID
            const data = localStorage.getItem(this.demoId);
            if (data) {
                return JSON.parse(data);
            }
            
            // Try to load from URL hash
            if (window.location.hash.startsWith('#data=')) {
                const encodedData = window.location.hash.substring(6);
                const decodedData = JSON.parse(atob(encodedData));
                return decodedData;
            }
            
            return { users: [], orders: [] };
        } catch (error) {
            console.log('Load failed:', error);
            return { users: [], orders: [] };
        }
    }
}

window.CloudSync = new SimpleCloudDB();
