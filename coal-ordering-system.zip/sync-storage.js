// Hybrid storage solution - localStorage with cross-device sync
class SyncStorage {
    constructor() {
        this.syncKey = 'coal-app-sync-' + Date.now();
        this.lastSync = localStorage.getItem('lastSyncTime') || '0';
    }

    // Save data with timestamp
    saveUsers(users) {
        const data = {
            users,
            timestamp: Date.now(),
            syncKey: this.syncKey
        };
        localStorage.setItem('coalUsers', JSON.stringify(users));
        localStorage.setItem('coalUsersSync', JSON.stringify(data));
        return users;
    }

    saveOrders(orders) {
        const data = {
            orders,
            timestamp: Date.now(),
            syncKey: this.syncKey
        };
        localStorage.setItem('adminOrders', JSON.stringify(orders));
        localStorage.setItem('coalOrdersSync', JSON.stringify(data));
        return orders;
    }

    // Get data with sync check
    getUsers() {
        return JSON.parse(localStorage.getItem('coalUsers') || '[]');
    }

    getOrders() {
        return JSON.parse(localStorage.getItem('adminOrders') || '[]');
    }

    // Simple sync mechanism using URL sharing
    generateSyncURL() {
        const users = this.getUsers();
        const orders = this.getOrders();
        const data = btoa(JSON.stringify({ users, orders }));
        return `${window.location.origin}${window.location.pathname}?sync=${data}`;
    }

    // Load from sync URL
    loadFromSync() {
        const urlParams = new URLSearchParams(window.location.search);
        const syncData = urlParams.get('sync');
        
        if (syncData) {
            try {
                const data = JSON.parse(atob(syncData));
                if (data.users) {
                    localStorage.setItem('coalUsers', JSON.stringify(data.users));
                }
                if (data.orders) {
                    localStorage.setItem('adminOrders', JSON.stringify(data.orders));
                }
                // Clean URL
                window.history.replaceState({}, document.title, window.location.pathname);
                return true;
            } catch (error) {
                console.error('Sync error:', error);
            }
        }
        return false;
    }
}

window.syncStorage = new SyncStorage();
