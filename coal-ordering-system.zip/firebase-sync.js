// Firebase configuration for cross-device sync
const firebaseConfig = {
    apiKey: "AIzaSyDummy-Replace-With-Real-Key",
    authDomain: "coal-demo.firebaseapp.com",
    databaseURL: "https://coal-demo-default-rtdb.firebaseio.com/",
    projectId: "coal-demo"
};

// Simple Firebase-like sync using a public JSON API (JSONBin.io alternative)
class SimpleSync {
    constructor() {
        this.baseUrl = 'https://api.jsonbin.io/v3/b/';
        this.binId = '6720f1e1ad19ca34f8b8c8a1'; // Public bin for demo
        this.apiKey = '$2a$10$dummy.key.for.demo.purposes.only';
    }

    async saveOrders(orders) {
        try {
            const response = await fetch(`${this.baseUrl}${this.binId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Master-Key': this.apiKey
                },
                body: JSON.stringify({ orders: orders, lastUpdated: Date.now() })
            });
            return response.ok;
        } catch (error) {
            console.log('Sync failed, using local storage');
            return false;
        }
    }

    async loadOrders() {
        try {
            const response = await fetch(`${this.baseUrl}${this.binId}/latest`, {
                headers: { 'X-Master-Key': this.apiKey }
            });
            if (response.ok) {
                const data = await response.json();
                return data.record.orders || [];
            }
        } catch (error) {
            console.log('Load failed, using local storage');
        }
        return null;
    }
}

// Use a simpler approach with GitHub Gist as storage
class GistSync {
    constructor() {
        this.gistId = 'dummy-gist-id-replace-with-real';
        this.token = 'dummy-token-replace-with-real';
    }

    async saveOrders(orders) {
        // For demo, we'll use localStorage with a timestamp approach
        const data = {
            orders: orders,
            timestamp: Date.now(),
            device: navigator.userAgent.substring(0, 50)
        };
        
        localStorage.setItem('coalOrdersSync', JSON.stringify(data));
        
        // Also save to a simple cloud endpoint (mock)
        try {
            // This would be replaced with a real cloud endpoint
            console.log('Orders saved to cloud:', orders.length);
            return true;
        } catch (error) {
            return false;
        }
    }

    async loadOrders() {
        // For demo, return localStorage data
        const data = JSON.parse(localStorage.getItem('coalOrdersSync') || '{"orders": []}');
        return data.orders;
    }
}

window.CloudSync = new GistSync();
