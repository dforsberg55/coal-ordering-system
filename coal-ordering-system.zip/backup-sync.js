// Backup cloud sync using multiple services for reliability
class BackupCloudSync {
    constructor() {
        this.storageKey = 'coalDemoData';
        this.services = [
            {
                name: 'JSONBin',
                endpoint: 'https://api.jsonbin.io/v3/b/67220b5ead19ca34f8c8b8c9',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Master-Key': '$2a$10$vQ8Z8Z8Z8Z8Z8Z8Z8Z8Z8u'
                }
            },
            {
                name: 'GitHub Gist',
                endpoint: 'https://api.github.com/gists/your-gist-id',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'token your-github-token'
                }
            }
        ];
    }

    async saveData(data) {
        // Always save locally first
        localStorage.setItem(this.storageKey, JSON.stringify(data));
        
        // Try to save to cloud services
        let cloudSaveSuccess = false;
        
        for (const service of this.services) {
            try {
                const response = await fetch(service.endpoint, {
                    method: 'PUT',
                    headers: service.headers,
                    body: JSON.stringify(data)
                });
                
                if (response.ok) {
                    console.log(`Data saved to ${service.name}`);
                    cloudSaveSuccess = true;
                    break; // Success with one service is enough
                }
            } catch (error) {
                console.log(`${service.name} save failed:`, error);
            }
        }
        
        if (cloudSaveSuccess) {
            console.log('Data saved to cloud and locally');
        } else {
            console.log('Cloud save failed, data saved locally only');
        }
        
        return true;
    }

    async loadData() {
        // Try cloud services first
        for (const service of this.services) {
            try {
                const response = await fetch(service.endpoint + '/latest', {
                    headers: service.headers
                });
                
                if (response.ok) {
                    const cloudData = await response.json();
                    if (cloudData && cloudData.record) {
                        localStorage.setItem(this.storageKey, JSON.stringify(cloudData.record));
                        console.log(`Data loaded from ${service.name}`);
                        return cloudData.record;
                    }
                }
            } catch (error) {
                console.log(`${service.name} load failed:`, error);
            }
        }
        
        // Fallback to localStorage
        const localData = localStorage.getItem(this.storageKey);
        if (localData) {
            console.log('Data loaded from local storage');
            return JSON.parse(localData);
        }
        
        return { users: [], orders: [] };
    }
}

// Uncomment to use backup sync instead of regular CloudSync
// window.CloudSync = new BackupCloudSync();