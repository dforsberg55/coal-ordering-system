const AWS = require('aws-sdk');

AWS.config.update({ region: 'eu-west-1' });
const dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
    };

    try {
        const { httpMethod, path, body } = event;

        if (httpMethod === 'OPTIONS') {
            return { statusCode: 200, headers };
        }

        if (path === '/health') {
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({ status: 'OK', timestamp: new Date().toISOString() })
            };
        }

        if (path === '/api/products' && httpMethod === 'GET') {
            const result = await dynamodb.scan({ TableName: 'coal-products' }).promise();
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify(result.Items)
            };
        }

        if (path === '/api/orders' && httpMethod === 'POST') {
            const { customerId, productId, quantity, totalAmount } = JSON.parse(body);
            
            const order = {
                orderId: `order-${Date.now()}`,
                customerId,
                productId,
                quantity,
                totalAmount,
                status: 'pending_approval',
                createdAt: new Date().toISOString()
            };

            await dynamodb.put({ TableName: 'coal-orders', Item: order }).promise();
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify(order)
            };
        }

        return {
            statusCode: 404,
            headers,
            body: JSON.stringify({ error: 'Not found' })
        };

    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: error.message })
        };
    }
};
