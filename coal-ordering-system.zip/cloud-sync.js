// Real cloud sync using JSONBin.io (free service)
class CloudSync {
    constructor() {
        // Using a public JSONBin for demo - replace with your own
        this.binId = '672100e1ad19ca34f8b8c8a5';
        this.apiKey = '$2a$10$Vq8P5zQzQzQzQzQzQzQzQeQzQzQzQzQzQzQzQzQzQzQzQzQzQzQzQz';
        this.baseUrl = 'https://api.jsonbin.io/v3/b/';
    }

    async saveData(data) {
        try {
            const response = await fetch(`${this.baseUrl}${this.binId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Master-Key': this.apiKey,
                    'X-Bin-Name': 'coal-orders-demo'
                },
                body: JSON.stringify({
                    users: data.users || [],
                    orders: data.orders || [],
                    lastUpdated: Date.now(),
                    version: '1.0'
                })
            });
            
            if (response.ok) {
                console.log('Data synced to cloud successfully');
                return true;
            }
        } catch (error) {
            console.log('Cloud sync failed:', error);
        }
        return false;
    }

    async loadData() {
        try {
            const response = await fetch(`${this.baseUrl}${this.binId}/latest`, {
                headers: {
                    'X-Master-Key': this.apiKey
                }
            });
            
            if (response.ok) {
                const result = await response.json();
                return result.record || { users: [], orders: [] };
            }
        } catch (error) {
            console.log('Cloud load failed:', error);
        }
        return { users: [], orders: [] };
    }
}

// Fallback using a simple HTTP endpoint
class SimpleCloudSync {
    constructor() {
        this.endpoint = 'https://httpbin.org/anything/coal-demo';
    }

    async saveData(data) {
        try {
            // For demo, we'll use localStorage with a timestamp approach
            const cloudData = {
                ...data,
                timestamp: Date.now(),
                device: navigator.userAgent.substring(0, 30)
            };
            
            // Save to localStorage with cloud prefix for cross-tab sync
            localStorage.setItem('coalCloudData', JSON.stringify(cloudData));
            
            // Also try to save to a real endpoint (will fail but that's ok for demo)
            fetch(this.endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(cloudData)
            }).catch(() => {});
            
            return true;
        } catch (error) {
            return false;
        }
    }

    async loadData() {
        try {
            const data = localStorage.getItem('coalCloudData');
            if (data) {
                return JSON.parse(data);
            }
        } catch (error) {}
        return { users: [], orders: [] };
    }
}

window.CloudSync = new SimpleCloudSync();
