// Simple API service to connect to your existing AWS infrastructure
class CoalAPI {
    constructor() {
        // Your existing API Gateway endpoint
        this.baseURL = 'https://8et3ccjf83.execute-api.eu-west-1.amazonaws.com/prod';
    }

    async saveUser(user) {
        try {
            const response = await fetch(`${this.baseURL}/api/users`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(user)
            });
            return await response.json();
        } catch (error) {
            console.error('Error saving user:', error);
            // Fallback to localStorage
            const users = JSON.parse(localStorage.getItem('coalUsers') || '[]');
            users.push(user);
            localStorage.setItem('coalUsers', JSON.stringify(users));
            return user;
        }
    }

    async getUsers() {
        try {
            const response = await fetch(`${this.baseURL}/api/users`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching users:', error);
            // Fallback to localStorage
            return JSON.parse(localStorage.getItem('coalUsers') || '[]');
        }
    }

    async saveOrder(order) {
        try {
            const response = await fetch(`${this.baseURL}/api/orders`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(order)
            });
            return await response.json();
        } catch (error) {
            console.error('Error saving order:', error);
            // Fallback to localStorage
            const orders = JSON.parse(localStorage.getItem('adminOrders') || '[]');
            orders.push(order);
            localStorage.setItem('adminOrders', JSON.stringify(orders));
            return order;
        }
    }

    async getOrders() {
        try {
            const response = await fetch(`${this.baseURL}/api/orders`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching orders:', error);
            // Fallback to localStorage
            return JSON.parse(localStorage.getItem('adminOrders') || '[]');
        }
    }
}

// Global API instance
window.coalAPI = new CoalAPI();
