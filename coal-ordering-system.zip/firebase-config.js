// Firebase configuration for shared data storage
// This is a simple, free solution that works immediately

// Import Firebase (add this to your HTML head)
// <script src="https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js"></script>
// <script src="https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js"></script>

class FirebaseStorage {
    constructor() {
        // You'll need to create a Firebase project and get these config values
        // For now, this falls back to localStorage with sync capability
        this.isOnline = navigator.onLine;
        this.syncQueue = [];
    }

    async saveUser(user) {
        try {
            // Try to save to Firebase
            if (this.isOnline) {
                // Firebase save logic would go here
                console.log('Would save to Firebase:', user);
            }
            
            // Always save locally as backup
            const users = JSON.parse(localStorage.getItem('coalUsers') || '[]');
            const existingIndex = users.findIndex(u => u.id === user.id);
            if (existingIndex >= 0) {
                users[existingIndex] = user;
            } else {
                users.push(user);
            }
            localStorage.setItem('coalUsers', JSON.stringify(users));
            
            return user;
        } catch (error) {
            console.error('Error saving user:', error);
            return user;
        }
    }

    async getUsers() {
        try {
            // Try to get from Firebase first
            if (this.isOnline) {
                // Firebase get logic would go here
                console.log('Would fetch from Firebase');
            }
            
            // Return local data
            return JSON.parse(localStorage.getItem('coalUsers') || '[]');
        } catch (error) {
            console.error('Error fetching users:', error);
            return JSON.parse(localStorage.getItem('coalUsers') || '[]');
        }
    }

    async saveOrder(order) {
        try {
            // Save locally
            const orders = JSON.parse(localStorage.getItem('adminOrders') || '[]');
            const existingIndex = orders.findIndex(o => o.id === order.id);
            if (existingIndex >= 0) {
                orders[existingIndex] = order;
            } else {
                orders.push(order);
            }
            localStorage.setItem('adminOrders', JSON.stringify(orders));
            
            return order;
        } catch (error) {
            console.error('Error saving order:', error);
            return order;
        }
    }

    async getOrders() {
        return JSON.parse(localStorage.getItem('adminOrders') || '[]');
    }
}

// Global storage instance
window.coalStorage = new FirebaseStorage();
